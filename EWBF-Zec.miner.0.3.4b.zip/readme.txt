Nvidia miner for nanopool,

According to the author of the miner it is designed for Nvidia Pascal GPUs and works with Nvidia GPUs with at least 1 GB of video memory.

The EWBF CUDA Zcash Miner has a built-in developer fee that is set at 2%, meaning that every 10 minutes the software will switch to a different pool and mine for the developer some shares and then get back to mining for you.

Note: For AMD GPU's try claymore.

Original download from nanopool: https://github.com/nanopool/ewbf-miner/releases