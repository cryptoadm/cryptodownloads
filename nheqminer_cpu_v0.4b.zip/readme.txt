#To start just execute
start.bat